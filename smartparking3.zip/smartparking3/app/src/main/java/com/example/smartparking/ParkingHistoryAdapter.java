package com.example.smartparking;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class ParkingHistoryAdapter extends BaseAdapter {

    private Context context;
    private ArrayList<ParkingHistory> parkingHistoryList;

    public ParkingHistoryAdapter(Context context, ArrayList<ParkingHistory> parkingHistoryList) {
        this.context = context;
        this.parkingHistoryList = new ArrayList<>(parkingHistoryList); // Create a copy to avoid direct modification issues
    }

    @Override
    public int getCount() {
        return parkingHistoryList.size();
    }

    @Override
    public Object getItem(int position) {
        return parkingHistoryList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_parking_history, parent, false);
        }

        ParkingHistory history = parkingHistoryList.get(position);

        TextView tvSlot = convertView.findViewById(R.id.tvSlot);
        TextView tvDate = convertView.findViewById(R.id.tvDate);
        TextView tvTime = convertView.findViewById(R.id.tvTime);
        TextView tvStatus = convertView.findViewById(R.id.tvStatus); // Ensure this TextView exists in your XML


        tvSlot.setText("Slot: " + history.getSlot());
        tvDate.setText("Date: " + history.getDate());
        tvTime.setText("Time: " + history.getTime());
        tvStatus.setText("Status: " + history.getStatus());


        return convertView;
    }

    // Method to update data dynamically
    public void updateData(ArrayList<ParkingHistory> newData) {
        this.parkingHistoryList.clear();
        this.parkingHistoryList.addAll(newData);
        notifyDataSetChanged(); // Refresh list view
    }
}
