package com.example.smartparking;

public class ParkingHistory {
    private String slot;
    private String date;
    private String time;
    private String status;


    private long timestamp;

    public ParkingHistory() {}

    public ParkingHistory( String slot, String date, String time, String status, long timestamp) {

        this.slot = slot;
        this.date = date;
        this.time = time;
        this.status = status;
        this.timestamp = timestamp;
    }


    public String getSlot() { return slot; }
    public String getDate() { return date; }
    public String getTime() { return time; }
    public String getStatus() { return status; }
    public long getTimestamp() { return timestamp; }
}
