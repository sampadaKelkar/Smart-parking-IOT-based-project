package com.example.smartparking;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class AdminActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        BottomNavigationView bottomNavigationView = findViewById(R.id.admin_bottom_navigation);

        // Set default fragment
        loadFragment(new AdminHomeFragment());  // Default fragment on start

        bottomNavigationView.setOnItemSelectedListener(item -> {
            Fragment selectedFragment = null;
            int itemId = item.getItemId();

            if (itemId == R.id.admin_home) {
                selectedFragment = new AdminHomeFragment();  // Navigate to Home
            } else if (itemId == R.id.admin_profile) {
                selectedFragment = new AdminProfileFragment();  // Navigate to Profile
            } else if (itemId == R.id.admin_settings) {
                selectedFragment = new AdminSettingsFragment();  // Navigate to Settings
            } else if (itemId == R.id.admin_report) {  // Add this case for Reports
                selectedFragment = new AdminReportFragment();  // Navigate to Reports
            }

            return loadFragment(selectedFragment);  // Load the selected fragment
        });
    }

    private boolean loadFragment(Fragment fragment) {
        if (fragment != null) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, fragment).commit();
            return true;
        }
        return false;
    }
}
