package com.example.smartparking;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.fragment.app.Fragment;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class HomeFragment extends Fragment {

    // Track if a slot is marked as "Out of Service"
    private boolean[] isOutOfService = new boolean[6];
    private String[] lastStatus = new String[6]; // Track previous status of each slot

    public HomeFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        String[] sensorKeys = {"irSensor1", "irSensor2", "irSensor3", "irSensor4", "irSensor5", "irSensor6"};
        int[] indicatorIds = {R.id.indicator_a1, R.id.indicator_a2, R.id.indicator_a3, R.id.indicator_a4, R.id.indicator_a5, R.id.indicator_a6};
        int[] statusTextIds = {R.id.indicator_a1, R.id.indicator_a2, R.id.indicator_a3, R.id.indicator_a4, R.id.indicator_a5, R.id.indicator_a6};

        // Initialize out-of-service states and last statuses
        for (int i = 0; i < 6; i++) {
            isOutOfService[i] = false;
            lastStatus[i] = null; // Default last status to null
        }

        for (int i = 0; i < sensorKeys.length; i++) {
            View indicator = view.findViewById(indicatorIds[i]);
            TextView statusText = view.findViewById(statusTextIds[i]);

            if (indicator != null && statusText != null) {
                listenForUpdates(indicator, statusText, sensorKeys[i], i);
            } else {
                Log.e("HomeFragment", "Indicator or Status Text view with ID " + indicatorIds[i] + " not found.");
            }
        }

        return view;
    }

    private void listenForUpdates(View indicator, TextView statusText, String sensorKey, int index) {
        DatabaseReference sensorRef = FirebaseDatabase.getInstance(
                "https://loginn-firebase-d550b-default-rtdb.asia-southeast1.firebasedatabase.app"
        ).getReference(sensorKey);

        sensorRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (snapshot.exists() && snapshot.hasChild("status") && snapshot.hasChild("locked")) {
                    String status = snapshot.child("status").getValue(String.class);
                    boolean isLocked = snapshot.child("locked").getValue(Boolean.class);

                    if (!isLocked && !isOutOfService[index]) {
                        updateIndicatorAndText(indicator, statusText, status);

                        // Prevent duplicate history entries
                        if (lastStatus[index] != null && !lastStatus[index].equals(status)) {
                            long currentTime = System.currentTimeMillis();
                            long lastUpdateTime = snapshot.hasChild("lastUpdateTime") ? snapshot.child("lastUpdateTime").getValue(Long.class) : 0;

                            // Ensure at least 5 seconds gap between status updates to prevent duplicates
                            if (currentTime - lastUpdateTime > 5000) {
                                if ("Not Detected".equals(lastStatus[index]) && "Detected".equals(status)) {
                                    saveParkingHistory(sensorKey, "Parked");
                                    sensorRef.child("lastUpdateTime").setValue(currentTime); // Save update time
                                } else if ("Detected".equals(lastStatus[index]) && "Not Detected".equals(status)) {
                                    saveParkingHistory(sensorKey, "Unparked");
                                    sensorRef.child("lastUpdateTime").setValue(currentTime); // Save update time
                                }
                            }
                        }

                        lastStatus[index] = status; // Update last known status
                    } else {
                        Log.d("HomeFragment", "Slot is locked or out of service, not updating indicator");
                    }
                } else {
                    Log.d("HomeFragment", "Sensor: " + sensorKey + " not found in database");
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Log.e("HomeFragment", "Database error: " + error.getMessage());
            }
        });
    }



    private void updateIndicatorAndText(View indicator, TextView statusText, String status) {
        if (getActivity() == null || !isAdded()) return; // Check if fragment is attached

        requireActivity().runOnUiThread(() -> {
            if (status == null) {
                Log.e("HomeFragment", "Received null status for indicator");
                return;
            }

            // Handle indicator updates and text
            switch (status) {
                case "Not Detected":  // Empty slot
                    indicator.setBackgroundColor(Color.GREEN); // Available slot
                    statusText.setText("Available");
                    break;
                case "Detected":  // Occupied slot
                    indicator.setBackgroundColor(Color.RED); // Occupied slot
                    statusText.setText("Occupied");
                    break;
                case "Out of Service":  // Admin sets slot to maintenance
                    indicator.setBackgroundColor(Color.GRAY); // Maintenance mode
                    statusText.setText("Out of Service");
                    break;
                default:
                    Log.e("HomeFragment", "Unknown status: " + status);
                    break;
            }
        });
    }

    // Call this method from Admin to mark a slot as "Out of Service"
    public void setSlotOutOfService(int slotIndex, boolean isOutOfService) {
        this.isOutOfService[slotIndex] = isOutOfService;
    }

    private void saveParkingHistory(String slot, String status) {
        FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        String userId = firebaseAuth.getCurrentUser().getUid();

        String historyId = db.collection("last").document(userId).collection("parkingHistory").document().getId();
        long timestamp = System.currentTimeMillis();

        Map<String, Object> history = new HashMap<>();
        history.put("slot", slot);
        history.put("date", new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date()));
        history.put("time", new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date()));
        history.put("status", status);
        history.put("timestamp", timestamp);

        db.collection("last").document(userId).collection("parkingHistory").document(historyId).set(history)
                .addOnSuccessListener(aVoid -> Log.d("HomeFragment", status + " history saved"))
                .addOnFailureListener(e -> Log.e("HomeFragment", "Error saving " + status + " history", e));
    }
}
