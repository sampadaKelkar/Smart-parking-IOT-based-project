package com.example.smartparking;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class SettingsFragment extends Fragment {
    private String selectedSpot = ""; // Stores selected parking spot
    private String selectedIssue = ""; // Stores selected issue

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_settings, container, false);

        Spinner spotSpinner = view.findViewById(R.id.spot_spinner);
        Spinner reportSpinner = view.findViewById(R.id.report_spinner);
        Button reportButton = view.findViewById(R.id.report_button);
        Button logout = view.findViewById(R.id.logout_button);

        logout.setOnClickListener(v -> logoutUser());

        // Set up Parking Spot Spinner
        ArrayAdapter<CharSequence> spotAdapter = ArrayAdapter.createFromResource(
                requireContext(), R.array.parking_spots, android.R.layout.simple_spinner_item);
        spotAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spotSpinner.setAdapter(spotAdapter);

        spotSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position != 0) { // Ignore default option
                    selectedSpot = parent.getItemAtPosition(position).toString();
                }
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        // Set up Issue Spinner
        ArrayAdapter<CharSequence> reportAdapter = ArrayAdapter.createFromResource(
                requireContext(), R.array.report_options, android.R.layout.simple_spinner_item);
        reportAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        reportSpinner.setAdapter(reportAdapter);

        reportSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position != 0) { // Ignore default option
                    selectedIssue = parent.getItemAtPosition(position).toString();
                }
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        // Handle Report Submission
        reportButton.setOnClickListener(v -> {
            if (selectedSpot.isEmpty() || selectedIssue.isEmpty()) {
                Toast.makeText(requireContext(), "Please select both spot and issue", Toast.LENGTH_SHORT).show();
            } else {
                submitReportToFirestore(selectedSpot, selectedIssue);
            }
        });

        return view;
    }

    private void logoutUser() {
        FirebaseAuth.getInstance().signOut(); // Firebase logout

        // Clear SharedPreferences session for normal users
        SharedPreferences sharedPreferences = requireActivity().getSharedPreferences("LoginPrefs", Context.MODE_PRIVATE);
        sharedPreferences.edit().putBoolean("isLoggedIn", false).apply();

        // Redirect to SelectionActivity
        Intent intent = new Intent(requireActivity(), SelectionActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK); // Prevent back navigation
        startActivity(intent);
    }

    private void submitReportToFirestore(String spot, String issue) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        String email = (user != null) ? user.getEmail() : "Unknown";

        // Create report data
        Map<String, Object> reportData = new HashMap<>();
        reportData.put("email", email);
        reportData.put("spot", spot);
        reportData.put("issue", issue);
        reportData.put("timestamp", timestamp);

        // Store report in Firestore under "Reports" collection
        db.collection("Reports")
                .add(reportData)
                .addOnSuccessListener(documentReference -> {
                    Toast.makeText(requireContext(), "Report submitted successfully", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(requireContext(), "Error submitting report: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }
}
