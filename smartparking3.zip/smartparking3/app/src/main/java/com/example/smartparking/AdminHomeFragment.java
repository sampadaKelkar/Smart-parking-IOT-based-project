package com.example.smartparking;

import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class AdminHomeFragment extends Fragment {

    private TextView[] slotViews;
    private String[] sensorKeys = {"irSensor1", "irSensor2", "irSensor3", "irSensor4", "irSensor5", "irSensor6"};
    private DatabaseReference databaseRef;
    private boolean[] isOutOfService = new boolean[sensorKeys.length];
    private boolean[] isLocked = new boolean[sensorKeys.length]; // Track "locked" status of slots
    private Button updateAllButton;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.admin_fragment_home, container, false);

        slotViews = new TextView[] {
                view.findViewById(R.id.status_a1),
                view.findViewById(R.id.status_a2),
                view.findViewById(R.id.status_a3),
                view.findViewById(R.id.status_a4),
                view.findViewById(R.id.status_a5),
                view.findViewById(R.id.status_a6)
        };

        updateAllButton = view.findViewById(R.id.update_all_button);  // Initialize Update All button
        updateAllButton.setOnClickListener(v -> showUpdateAllDialog());  // Set onClick listener

        databaseRef = FirebaseDatabase.getInstance(
                "https://loginn-firebase-d550b-default-rtdb.asia-southeast1.firebasedatabase.app"
        ).getReference();

        // Listening for updates to slot statuses and locked status
        for (int i = 0; i < sensorKeys.length; i++) {
            int index = i;
            listenForUpdates(slotViews[i], sensorKeys[i], index);
            listenForLockedStatus(sensorKeys[i], index); // Listen for locked status updates
            slotViews[i].setOnClickListener(v -> showStatusDialog(slotViews[index], sensorKeys[index], index));
        }
        return view;
    }

    private void listenForUpdates(TextView slotView, String sensorKey, int index) {
        databaseRef.child(sensorKey).child("status").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists() && !isOutOfService[index] && !isLocked[index]) { // Only update if not locked
                    String status = snapshot.getValue(String.class);
                    Log.d("AdminHomeFragment", "Slot " + sensorKey + " status: " + status);
                    updateSlotStatus(slotView, status, index);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("AdminHomeFragment", "Failed to load data: " + error.getMessage());
                Toast.makeText(getContext(), "Failed to load data", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void listenForLockedStatus(String sensorKey, int index) {
        databaseRef.child(sensorKey).child("locked").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    isLocked[index] = snapshot.getValue(Boolean.class);
                    Log.d("AdminHomeFragment", "Slot " + sensorKey + " locked status: " + isLocked[index]);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("AdminHomeFragment", "Failed to load locked status: " + error.getMessage());
                Toast.makeText(getContext(), "Failed to load locked status", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updateSlotStatus(TextView textView, String status, int index) {
        if (status == null) return;
        Log.d("AdminHomeFragment", "Updating slot " + sensorKeys[index] + " status to: " + status);

        // Match the status from Arduino
        if (status.equals("Detected") || status.equals("Occupied")) {
            textView.setText("Occupied");
            textView.setBackgroundColor(Color.RED);
        } else if (status.equals("Not Detected")) {
            textView.setText("Available");
            textView.setBackgroundColor(Color.GREEN);
        } else if (status.equals("Out of Service")) {
            textView.setText("Out of Service");
            textView.setBackgroundColor(Color.GRAY);
        }
    }

    private void showStatusDialog(TextView slotView, String sensorKey, int index) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_change_status, null);
        builder.setView(dialogView);

        RadioGroup radioGroup = dialogView.findViewById(R.id.statusRadioGroup);
        RadioButton radioAvailable = dialogView.findViewById(R.id.radioAvailable);
        RadioButton radioMaintenance = dialogView.findViewById(R.id.radioMaintenance);

        builder.setPositiveButton("Save", (dialog, which) -> {
            if (radioAvailable.isChecked()) {
                // Update the status to "Not Detected" and set "locked" to false
                databaseRef.child(sensorKey).child("status").setValue("Not Detected");
                databaseRef.child(sensorKey).child("locked").setValue(false);
                slotView.setText("Available");
                slotView.setBackgroundColor(Color.GREEN);
                isOutOfService[index] = false;
                Log.d("AdminHomeFragment", "Slot " + sensorKey + " status changed to Available.");
            } else if (radioMaintenance.isChecked()) {
                // Update the status to "Out of Service" and set "locked" to true
                databaseRef.child(sensorKey).child("status").setValue("Out of Service");
                databaseRef.child(sensorKey).child("locked").setValue(true);
                slotView.setText("Out of Service");
                slotView.setBackgroundColor(Color.GRAY);
                isOutOfService[index] = true;
                Log.d("AdminHomeFragment", "Slot " + sensorKey + " status changed to Out of Service.");
            }
            dialog.dismiss();
        });
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());
        builder.show();
    }

    // Show dialog to select status for all slots
    private void showUpdateAllDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle("Update All Slots");

        // RadioGroup for selecting status
        String[] statuses = {"Available", "Out of Service"};
        builder.setSingleChoiceItems(statuses, -1, (dialog, which) -> {
            // Handle status selection
        });

        builder.setPositiveButton("Update", (dialog, which) -> {
            // Get selected status
            int selectedIndex = ((AlertDialog) dialog).getListView().getCheckedItemPosition();
            String selectedStatus = statuses[selectedIndex];

            // Update all slots with selected status
            updateAllSlots(selectedStatus);
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());
        builder.show();
    }

    // Update all slots with the selected status
    private void updateAllSlots(String status) {
        String newStatus;
        if ("Available".equals(status)) {
            newStatus = "Not Detected";
        } else {
            newStatus = "Out of Service";
        }

        for (int i = 0; i < sensorKeys.length; i++) {
            String sensorKey = sensorKeys[i];
            databaseRef.child(sensorKey).child("status").setValue(newStatus);
            databaseRef.child(sensorKey).child("locked").setValue(status.equals("Out of Service"));
            // Update the UI for all slots
            slotViews[i].setText(newStatus.equals("Not Detected") ? "Available" : "Out of Service");
            slotViews[i].setBackgroundColor(newStatus.equals("Not Detected") ? Color.GREEN : Color.GRAY);
        }
        Toast.makeText(getContext(), "All slots updated to " + status, Toast.LENGTH_SHORT).show();
    }
}
