package com.example.smartparking;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class ReportAdapter extends RecyclerView.Adapter<ReportAdapter.ReportViewHolder> {
    private final List<ReportModel> reportList;

    public ReportAdapter(List<ReportModel> reportList) {
        this.reportList = reportList;
    }

    @NonNull
    @Override
    public ReportViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_report, parent, false);
        return new ReportViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ReportViewHolder holder, int position) {
        ReportModel report = reportList.get(position);
        holder.emailTextView.setText("User: " + report.getEmail());
        holder.spotTextView.setText("Spot: " + report.getSpot());
        holder.issueTextView.setText("Issue: " + report.getIssue());
        holder.timestampTextView.setText("Time: " + report.getTimestamp());
    }

    @Override
    public int getItemCount() {
        return reportList.size();
    }

    static class ReportViewHolder extends RecyclerView.ViewHolder {
        TextView emailTextView, spotTextView, issueTextView, timestampTextView;

        public ReportViewHolder(View itemView) {
            super(itemView);
            emailTextView = itemView.findViewById(R.id.reportEmail);
            spotTextView = itemView.findViewById(R.id.reportSpot);
            issueTextView = itemView.findViewById(R.id.reportIssue);
            timestampTextView = itemView.findViewById(R.id.reportTimestamp);
        }
    }
}