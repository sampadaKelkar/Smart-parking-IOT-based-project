package com.example.smartparking;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.google.firebase.auth.FirebaseAuth;

public class AdminSettingsFragment extends Fragment {

    public AdminSettingsFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.admin_fragment_settings, container, false);

        // Handle Logout Button
        Button logoutButton = view.findViewById(R.id.admin_logout_button);
        logoutButton.setOnClickListener(v -> {
            FirebaseAuth.getInstance().signOut(); // Log out the admin
            Intent intent = new Intent(requireContext(), SelectionActivity.class); // Redirect to login
            startActivity(intent);
            requireActivity().finish();
        });

        return view;
    }
}
