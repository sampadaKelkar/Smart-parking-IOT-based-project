package com.example.smartparking;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class SelectionActivity extends AppCompatActivity {
    private SharedPreferences sharedPreferences;
    private static final String PREF_NAME = "LoginPrefs";
    private static final String KEY_IS_LOGGED_IN = "isLoggedIn";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selection);

        sharedPreferences = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        boolean isLoggedIn = sharedPreferences.getBoolean(KEY_IS_LOGGED_IN, false);

        // 🔍 Debugging: Log authentication and session status
        Log.d("SelectionActivity", "Firebase User: " + (currentUser != null ? "Exists" : "Null"));
        Log.d("SelectionActivity", "SharedPreferences Login Status: " + isLoggedIn);

        // If a normal user is logged in, redirect to MainActivity
        if (currentUser != null && isLoggedIn) {
            Log.d("SelectionActivity", "Redirecting to MainActivity");
            startActivity(new Intent(SelectionActivity.this, MainActivity.class));
            finish();
            return;
        }

        // If no normal user is logged in, show selection screen
        Button userButton = findViewById(R.id.btn_User);
        Button adminButton = findViewById(R.id.btn_admin);

        userButton.setOnClickListener(view -> {
            Intent intent = new Intent(SelectionActivity.this, LoginActivity.class);
            startActivity(intent);
        });

        adminButton.setOnClickListener(view -> {
            Intent intent = new Intent(SelectionActivity.this, Admin_LoginActivity.class);
            startActivity(intent);
        });
    }
}
