package com.example.smartparking;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.animation.*;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        ImageView logo = findViewById(R.id.logo); // Get logo reference

        // Animation Set for entrance
        AnimationSet enterAnimation = new AnimationSet(true);

        // Scale Up with Bounce
        ScaleAnimation scaleUp = new ScaleAnimation(
                0.5f, 1.5f, // Scale from 50% to 150%
                0.5f, 1.5f,
                Animation.RELATIVE_TO_SELF, 0.5f,
                Animation.RELATIVE_TO_SELF, 0.5f
        );
        scaleUp.setInterpolator(new OvershootInterpolator(1.8f)); // Bounce effect
        scaleUp.setDuration(1000);

        // Fade In
        AlphaAnimation fadeIn = new AlphaAnimation(0.2f, 1f);
        fadeIn.setDuration(1000);

        // Glow Effect (Pulse)
        ScaleAnimation pulse = new ScaleAnimation(
                1.2f, 1.3f, 1.2f, 1.3f,
                Animation.RELATIVE_TO_SELF, 0.5f,
                Animation.RELATIVE_TO_SELF, 0.5f
        );
        pulse.setInterpolator(new CycleInterpolator(2));
        pulse.setDuration(500);
        pulse.setStartOffset(1000); // Starts after fade-in

        // Combine all entrance animations
        enterAnimation.addAnimation(scaleUp);
        enterAnimation.addAnimation(fadeIn);
        enterAnimation.addAnimation(pulse);
        logo.startAnimation(enterAnimation);

        // Splash Out Effect After Delay
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            AnimationSet exitAnimation = new AnimationSet(true);

            // Smooth Shrinking + Rotation
            ScaleAnimation scaleDown = new ScaleAnimation(
                    1.5f, 0.1f, // Shrink from 150% to almost nothing
                    1.5f, 0.1f,
                    Animation.RELATIVE_TO_SELF, 0.5f,
                    Animation.RELATIVE_TO_SELF, 0.5f
            );
            scaleDown.setDuration(700);
            scaleDown.setInterpolator(new AccelerateInterpolator());

            RotateAnimation rotateOut = new RotateAnimation(
                    0, 360, // Full spin rotation
                    Animation.RELATIVE_TO_SELF, 0.5f,
                    Animation.RELATIVE_TO_SELF, 0.5f
            );
            rotateOut.setDuration(700);
            rotateOut.setInterpolator(new AccelerateInterpolator());

            // Fade Out
            AlphaAnimation fadeOut = new AlphaAnimation(1f, 0f);
            fadeOut.setDuration(700);

            // Combine exit animations
            exitAnimation.addAnimation(scaleDown);
            exitAnimation.addAnimation(rotateOut);
            exitAnimation.addAnimation(fadeOut);
            logo.startAnimation(exitAnimation);

            // Start main activity after animation completes
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                Intent intent = new Intent(SplashActivity.this, SelectionActivity.class);
                startActivity(intent);
                finish();
            }, 700);
        }, 1800); // Wait before splash-out effect
    }
}
