package com.example.smartparking;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;

public class ProfileFragment extends Fragment {

    private ListView lvParkingHistory;
    private FirebaseAuth firebaseAuth;
    private FirebaseFirestore db;
    private TextView tvUsername, tvEmail;
    private ParkingHistoryAdapter parkingHistoryAdapter;
    private ArrayList<ParkingHistory> parkingHistoryList;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_profile, container, false);

        // Initialize UI components
        lvParkingHistory = rootView.findViewById(R.id.lvParkingHistory);
        tvUsername = rootView.findViewById(R.id.tvUsername);
        tvEmail = rootView.findViewById(R.id.tvEmail);

        firebaseAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        parkingHistoryList = new ArrayList<>();
        parkingHistoryAdapter = new ParkingHistoryAdapter(getContext(), parkingHistoryList);
        lvParkingHistory.setAdapter(parkingHistoryAdapter);

        // Load user profile info
        loadUserInfo();

        // Load parking history
        loadParkingHistory();

        return rootView;
    }

    private void loadUserInfo() {
        // Load user info from Firebase Authentication
        String userId = firebaseAuth.getCurrentUser().getUid();
        db.collection("members")
                .document(userId)
                .get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        String username = documentSnapshot.getString("username");
                        String email = documentSnapshot.getString("email");

                        // Set user info in UI
                        tvUsername.setText("Username: " + username);
                        tvEmail.setText("Email: " + email);
                    }
                })
                .addOnFailureListener(e -> Log.e("ProfileFragment", "Error loading user info", e));
    }

    private void loadParkingHistory() {
        String userId = firebaseAuth.getCurrentUser().getUid();
        db.collection("members")
                .document(userId)
                .collection("parkingHistory")
                .orderBy("timestamp", Query.Direction.DESCENDING) // Latest first
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    ArrayList<ParkingHistory> newList = new ArrayList<>();
                    for (DocumentSnapshot doc : queryDocumentSnapshots.getDocuments()) {
                        ParkingHistory history = doc.toObject(ParkingHistory.class);
                        newList.add(history);
                    }
                    parkingHistoryAdapter.updateData(newList); // Update adapter properly
                })
                .addOnFailureListener(e -> Log.e("ProfileFragment", "Error fetching parking history", e));
    }

}

