package com.example.smartparking;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class Admin_LoginActivity extends AppCompatActivity {

    private static final String TAG = "Admin_LoginActivity"; // For logging

    // Predefined admin credentials
    private static final String ADMIN_EMAIL = "admin@gmail.com";
    private static final String ADMIN_PASSWORD = "admin1234";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.admin_activity_login);

        // Get references to UI elements
        EditText emailField = findViewById(R.id.Login_Email);
        EditText passwordField = findViewById(R.id.Login_Password);
        Button loginButton = findViewById(R.id.Login_button);

        // Ensure password is displayed as dots
        passwordField.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);

        // Handle the login button click
        loginButton.setOnClickListener(view -> {
            String email = emailField.getText().toString().trim();
            String password = passwordField.getText().toString().trim();

            Log.d(TAG, "Attempting login with email: " + email); // Debugging log

            // Validate credentials
            if (ADMIN_EMAIL.equals(email) && ADMIN_PASSWORD.equals(password)) {
                Log.d(TAG, "Admin credentials matched, navigating to AdminActivity.");
                Toast.makeText(Admin_LoginActivity.this, "Admin logged in successfully!", Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(Admin_LoginActivity.this, AdminActivity.class);
                startActivity(intent);
                finish(); // Close login activity
            } else {
                Log.d(TAG, "Invalid admin credentials entered.");
                Toast.makeText(Admin_LoginActivity.this, "Invalid admin credentials. Please try again.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
