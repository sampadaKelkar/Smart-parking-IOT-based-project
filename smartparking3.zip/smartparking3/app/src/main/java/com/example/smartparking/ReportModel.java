package com.example.smartparking;

public class ReportModel {
    private String email;
    private String spot;
    private String issue;
    private String timestamp;

    public ReportModel() { } // Empty constructor for Firestore

    public ReportModel(String email, String spot, String issue, String timestamp) {
        this.email = email;
        this.spot = spot;
        this.issue = issue;
        this.timestamp = timestamp;
    }

    public String getEmail() { return email; }
    public String getSpot() { return spot; }
    public String getIssue() { return issue; }
    public String getTimestamp() { return timestamp; }
}