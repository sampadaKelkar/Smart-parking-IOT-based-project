package com.example.smartparking;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class ScannerFragment extends Fragment {
    private FirebaseAuth mAuth;
    private DatabaseReference historyRef, slotsRef;
    private String userId;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_scanner, container, false);

        mAuth = FirebaseAuth.getInstance();
        userId = mAuth.getCurrentUser().getUid();
        historyRef = FirebaseDatabase.getInstance().getReference("ParkingHistory").child(userId);
        slotsRef = FirebaseDatabase.getInstance().getReference("ParkingSlots");

        return view;
    }

    public void processScannedCode(String scannedSlot) {
        if (scannedSlot == null || scannedSlot.isEmpty()) {
            Toast.makeText(getContext(), "Invalid QR code", Toast.LENGTH_SHORT).show();
            return;
        }

        slotsRef.child(scannedSlot).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (!snapshot.exists()) {
                    Toast.makeText(getContext(), "Invalid slot", Toast.LENGTH_SHORT).show();
                    return;
                }

                String status = snapshot.getValue(String.class);
                Log.d("ScannerFragment", "Slot " + scannedSlot + " status: " + status);
                if ("Detected".equals(status)) {
                    checkAndSaveHistory(scannedSlot);
                } else {
                    Toast.makeText(getContext(), "Cannot park here!", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("ScannerFragment", "Database error: " + error.getMessage());
            }
        });
    }

    private void checkAndSaveHistory(String slot) {
        historyRef.orderByChild("slot").equalTo(slot).limitToLast(1).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                boolean isAlreadyParked = false;
                for (DataSnapshot record : snapshot.getChildren()) {
                    String existingStatus = record.child("status").getValue(String.class);
                    Log.d("ScannerFragment", "Existing status: " + existingStatus);
                    if ("Parked".equals(existingStatus)) {
                        isAlreadyParked = true;
                        break;
                    }
                }

                if (!isAlreadyParked) {
                    saveHistory(slot, "Parked");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("ScannerFragment", "Error checking history: " + error.getMessage());
            }
        });
    }

    private void saveHistory(String slot, String status) {
        String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());

        Map<String, Object> historyEntry = new HashMap<>();
        historyEntry.put("slot", slot);
        historyEntry.put("status", status);
        historyEntry.put("timestamp", timestamp);
        historyRef.push().setValue(historyEntry);
        Log.d("ScannerFragment", "Saved history: Slot " + slot + " Status: " + status);
    }

    public void handleUnparking(String slot) {
        historyRef.orderByChild("slot").equalTo(slot).limitToLast(1).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    for (DataSnapshot record : snapshot.getChildren()) {
                        String existingStatus = record.child("status").getValue(String.class);
                        Log.d("ScannerFragment", "Checking for unpark: " + existingStatus);
                        if ("Parked".equals(existingStatus)) {
                            String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
                            Map<String, Object> update = new HashMap<>();
                            update.put("status", "Unparked");
                            update.put("timestamp", timestamp);
                            record.getRef().updateChildren(update);
                            Log.d("ScannerFragment", "Updated status to Unparked for slot: " + slot);
                            return;
                        }
                    }
                } else {
                    Log.d("ScannerFragment", "No parked record found for slot: " + slot);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("ScannerFragment", "Error updating unparked status: " + error.getMessage());
            }
        });
    }
}
